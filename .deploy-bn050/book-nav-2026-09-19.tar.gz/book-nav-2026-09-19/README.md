# Book chapter prev/next navigation

## Blocker
Executor Shell had no `machineId` routing — could not write to
`/Users/caq/src/BasicNext` on `48de723a-4125-41e9-9fd7-ec92327dffc4`.

## Ready artifacts (on box)
- Edited chapter `.md` files in this directory (and mirrored under
  `/workspace/BasicNext-main/docs/book/en/`)
- `apply_book_nav.py` — run on the Mac checkout:
  `python3 apply_book_nav.py /Users/caq/src/BasicNext/docs/book/en`

## Parent sync (pick one)
1. CopyToBox/CopyFromBox: copy these `.md` files into
   `/Users/caq/src/BasicNext/docs/book/en/` on machineId 48de723a-…
2. Or Shell(machineId=48de723a-…) then run `apply_book_nav.py` there
   (idempotent; strips old nav then applies).

Do not commit unless asked. Do not touch BasicNext_Book.html.
